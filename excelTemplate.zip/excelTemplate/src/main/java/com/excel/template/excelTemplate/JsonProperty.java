package com.excel.template.excelTemplate;

public @interface JsonProperty {

	String value();

}
