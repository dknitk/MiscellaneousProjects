package com.excel.template.excelTemplate;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.List;

import com.google.gson.Gson;
import com.grapecity.documents.excel.Workbook;

public class TemplateJSON {

	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		System.out.println("Application started");
		Workbook book = new Workbook();
		
		book.open("D:/projects/GitHub_Repository/excelTemplate/src/main/resources/Sales_Template.xlsx");
		System.out.println("Sales_Template.xlsx loaded in GcExcel");

		// Get data from json file
		// InputStreamReader reader = new InputStreamReader(GetResourceStream("D:/projects/GitHub_Repository/excelTemplate/src/main/resources/SalesData.json"));
		
		
		// initializing FileInputStream 
        FileInputStream geek = new FileInputStream("D:/projects/GitHub_Repository/excelTemplate/src/main/resources/SalesData.json"); 

        // Initializing InputStreamReader object 
        InputStreamReader reader = new InputStreamReader(geek, "utf-8"); 
		
	
		
		Gson gson = new Gson();
		RootObject datasource = gson.fromJson(reader, RootObject.class);
		// Add data source
		book.addDataSource("Sales", datasource.getSales());
		book.processTemplate();
		
		book.save("D:/projects/GitHub_Repository/excelTemplate/src/main/resources/SalesReport.xlsx");
		System.out.println("SalesReport.xlsx generated successfully");

	}

	public static InputStream GetResourceStream(String resource) {
		return TemplateJSON.class.getClassLoader().getResourceAsStream(resource);
	}

	public static class Item {
		@JsonProperty("ProductID")
		private int ProductID;

		public int getProductID() {
			return this.ProductID;
		}

		public void setProductID(int productID) {
			this.ProductID = productID;
		}

		@JsonProperty("Name")
		private String Name;

		public String getName() {
			return this.Name;
		}

		public void setName(String name) {
			this.Name = name;
		}

		@JsonProperty("Category")
		private String Category;

		public String getCategory() {
			return this.Category;
		}

		public void setCategory(String category) {
			this.Category = category;
		}

		@JsonProperty("Revenue")
		private double Revenue;

		public double getRevenue() {
			return this.Revenue;
		}

		public void setRevenue(double revenue) {
			this.Revenue = revenue;
		}

	}

	public static class Region {
		@JsonProperty("Area")
		private String Area;

		public String getArea() {
			return this.Area;
		}

		public void setArea(String area) {
			this.Area = area;
		}

		@JsonProperty("City")
		private String City;

		public String getCity() {
			return this.City;
		}

		public void setCity(String city) {
			this.City = city;
		}

	}

	public static class Sale {
		@JsonProperty("Duration")
		private String Duration;

		public String getDuration() {
			return this.Duration;
		}

		public void setDuration(String duration) {
			this.Duration = duration;
		}

		@JsonProperty("Region")
		public Region Region;

		public TemplateJSON.Region getRegion() {
			return this.Region;
		}

		public void setRegion(TemplateJSON.Region region) {
			this.Region = region;
		}

		@JsonProperty("Item")
		public Item Item;

		public TemplateJSON.Item getItem() {
			return this.Item;
		}

		public void setItem(TemplateJSON.Item item) {
			this.Item = item;
		}

		public Sale() {
			this.Item = new Item();
			this.Region = new Region();
		}

	}

	public class RootObject {
		@JsonProperty("Sales")
		private List<Sale> Sales;

		public List<Sale> getSales() {
			return this.Sales;
		}

		public void setSales(List<Sale> sales) {
			this.Sales = sales;
		}
	}
}
