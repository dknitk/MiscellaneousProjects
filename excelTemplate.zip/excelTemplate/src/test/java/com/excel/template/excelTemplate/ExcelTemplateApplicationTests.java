package com.excel.template.excelTemplate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExcelTemplateApplicationTests {

	@Test
	void contextLoads() {
	}

}
